/* Study Hub: real study-management tools, stored separately in localStorage. */
(() => {
  const KEY = 'jee370rStudyHubV1';
  const subjects = ['Physics','Chemistry','Mathematics'];
  const types = ['Lecture','Homework','DPP','PYQ','Revision','Practice','Mock Test'];
  const statuses = ['Not Started','Learning','Practicing','Revised','Mastered'];
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2,8);
  const today = () => (typeof localISODate === 'function' ? localISODate() : new Date().toISOString().slice(0,10));
  const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const defaultData = () => ({tasks:[], revisions:[], backlog:[], mistakes:[], tests:[], goals:[], sessions:[], chapters:[]});
  let data = load();
  function load(){ try{return {...defaultData(), ...(JSON.parse(localStorage.getItem(KEY)||'{}'))};}catch(e){return defaultData();} }
  function save(){localStorage.setItem(KEY,JSON.stringify(data)); render();}
  function el(id){return document.getElementById(id)}
  function open(){el('studyHubOverlay').hidden=false; render();}
  function close(){el('studyHubOverlay').hidden=true;}
  function activeTab(){return document.querySelector('.study-tab.active')?.dataset.tab || 'dashboard';}
  function setTab(tab){document.querySelectorAll('.study-tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.study-panel').forEach(p=>p.hidden=p.dataset.panel!==tab);render();}
  function sumSessions(filterDate){return data.sessions.filter(s=>!filterDate||s.date===filterDate).reduce((a,s)=>a+(Number(s.minutes)||0),0)}
  function questions(){return data.sessions.reduce((a,s)=>a+(Number(s.questions)||0),0)}
  function accuracy(){let a=data.sessions.reduce((x,s)=>x+(Number(s.questions)||0),0);let c=data.sessions.reduce((x,s)=>x+(Number(s.correct)||0),0);return a?Math.round(c/a*100):0}
  function streak(){let days=[...new Set(data.sessions.map(s=>s.date))].sort();if(!days.length)return 0;let set=new Set(days), cur=0,d=new Date();while(set.has(fmt(d))){cur++;d.setDate(d.getDate()-1)}return cur}
  function fmt(d){return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10)}
  function consistency(){const mins=sumSessions(today()), qs=data.sessions.filter(s=>s.date===today()).reduce((a,s)=>a+(+s.questions||0),0), done=data.tasks.filter(t=>t.date===today()&&t.done).length, total=data.tasks.filter(t=>t.date===today()).length;let score=Math.min(40,Math.round(mins/12))+Math.min(30,Math.round(qs/3))+Math.min(30,total?Math.round(done/total*30):0);return Math.min(100,score)}
  function recommendation(){
    const due=data.revisions.filter(r=>r.due<=today()).sort((a,b)=>a.due.localeCompare(b.due))[0]; if(due)return {title:`${due.subject} — ${due.chapter}`,sub:'Revision due today',meta:'Start with this revision'};
    const weak=data.chapters.filter(c=>c.accuracy!=null&&Number(c.accuracy)<60).sort((a,b)=>Number(a.accuracy)-Number(b.accuracy))[0]; if(weak)return {title:`${weak.subject} — ${weak.chapter}`,sub:`Accuracy ${weak.accuracy}%`,meta:'Concept revision + practice'};
    const task=data.tasks.filter(t=>t.date===today()&&!t.done).sort((a,b)=>({Critical:0,High:1,Medium:2,Low:3}[a.priority]??3)-({Critical:0,High:1,Medium:2,Low:3}[b.priority]??3))[0]; if(task)return {title:task.task,sub:`${task.subject} • ${task.type}`,meta:`${task.minutes||30} min`};
    const back=data.backlog.filter(b=>b.status!=='done').sort((a,b)=>({Critical:0,High:1,Medium:2,Low:3}[a.priority]??3)-({Critical:0,High:1,Medium:2,Low:3}[b.priority]??3))[0]; if(back)return {title:`Clear: ${back.chapter}`,sub:`${back.subject} • ${back.priority}`,meta:`~${back.hours||1}h`};
    return {title:'Plan your next study session',sub:'No urgent item found',meta:'Add a task, revision or backlog item'};
  }
  function render(){
    const tab=activeTab();
    if(tab==='dashboard') renderDashboard();
    if(tab==='tasks') renderTasks();
    if(tab==='revision') renderRevisions();
    if(tab==='backlog') renderBacklog();
    if(tab==='mistakes') renderMistakes();
    if(tab==='tests') renderTests();
    if(tab==='goals') renderGoals();
    if(tab==='analytics') renderAnalytics();
    el('studyStreak').textContent=streak();
  }
  function renderDashboard(){
    const todayTasks=data.tasks.filter(t=>t.date===today()), done=todayTasks.filter(t=>t.done).length, mins=sumSessions(today()), rec=recommendation();
    el('studyDash').innerHTML=`<div class="study-recommend"><div class="study-kicker">🎯 WHAT SHOULD I STUDY NOW?</div><h3>${esc(rec.title)}</h3><p>${esc(rec.sub)}</p><b>${esc(rec.meta)}</b><button class="primary" data-action="startRec">Start Session</button></div><div class="study-kpis"><div><b>${done}/${todayTasks.length}</b><span>Tasks today</span></div><div><b>${Math.floor(mins/60)}h ${mins%60}m</b><span>Focus today</span></div><div><b>${questions()}</b><span>Questions logged</span></div><div><b>${accuracy()}%</b><span>Accuracy</span></div><div><b>${data.revisions.filter(r=>r.due<=today()).length}</b><span>Revisions due</span></div><div><b>${consistency()}/100</b><span>Consistency</span></div></div><div class="study-grid-2"><div class="study-card"><h3>📋 Today's Tasks</h3>${todayTasks.length?todayTasks.slice(0,6).map(t=>`<label class="study-task-line"><input type="checkbox" data-task="${t.id}" ${t.done?'checked':''}> <span>${esc(t.task)}</span><small>${esc(t.subject)}</small></label>`).join(''):'<p class="muted">No tasks yet. Add your first task.</p>'}</div><div class="study-card"><h3>⚠️ Weak Areas</h3>${data.chapters.filter(c=>Number(c.accuracy)<60).slice(0,5).map(c=>`<div class="study-mini-row"><b>${esc(c.chapter)}</b><span>${esc(c.subject)} • ${c.accuracy}%</span></div>`).join('')||'<p class="muted">No weak areas detected yet.</p>'}</div></div>`;
  }
  function renderTasks(){const list=data.tasks.filter(t=>t.date===today());el('tasksList').innerHTML=list.length?list.map(t=>`<div class="study-item ${t.done?'is-done':''}"><div><b>${esc(t.task)}</b><small>${esc(t.subject)} • ${esc(t.type)} • ${esc(t.priority)} • ${t.minutes||30} min</small></div><div><button class="secondary" data-task-toggle="${t.id}">${t.done?'Undo':'Done'}</button><button class="danger" data-task-delete="${t.id}">×</button></div></div>`).join(''):'<p class="muted">No tasks for today.</p>'}
  function renderRevisions(){el('revisionList').innerHTML=data.revisions.sort((a,b)=>a.due.localeCompare(b.due)).map(r=>`<div class="study-item ${r.due<=today()?'due':''}"><div><b>${esc(r.chapter)}</b><small>${esc(r.subject)} • ${esc(r.level)} • Due ${esc(r.due)}</small></div><button class="primary" data-revision="${r.id}">${r.due<=today()?'Complete':'Done'}</button></div>`).join('')||'<p class="muted">No revisions scheduled.</p>'}
  function renderBacklog(){el('backlogList').innerHTML=data.backlog.map(b=>`<div class="study-item"><div><b>${esc(b.chapter)}</b><small>${esc(b.subject)} • ${esc(b.priority)} • ~${b.hours||1}h</small></div><div><button class="secondary" data-backlog="${b.id}">${b.status==='done'?'Undo':'Complete'}</button><button class="danger" data-backlog-delete="${b.id}">×</button></div></div>`).join('')||'<p class="muted">Backlog is empty 🎉</p>'}
  function renderMistakes(){el('mistakeList').innerHTML=data.mistakes.map(m=>`<div class="study-item"><div><b>${esc(m.topic)}</b><small>${esc(m.subject)} • ${esc(m.type)}</small><p>${esc(m.note||'')}</p></div><button class="danger" data-mistake-delete="${m.id}">×</button></div>`).join('')||'<p class="muted">No mistakes recorded.</p>'}
  function renderTests(){el('testList').innerHTML=data.tests.map(t=>{const acc=t.attempted?Math.round(t.correct/t.attempted*100):0;return `<div class="study-item"><div><b>${esc(t.name)}</b><small>${esc(t.date)} • ${t.score}/${t.max} • Accuracy ${acc}%</small></div><button class="danger" data-test-delete="${t.id}">×</button></div>`}).join('')||'<p class="muted">No mock tests recorded.</p>'}
  function renderGoals(){el('goalList').innerHTML=data.goals.map(g=>{const p=Math.min(100,Math.round((Number(g.current)||0)/(Number(g.target)||1)*100));return `<div class="study-goal"><div><b>${esc(g.name)}</b><span>${g.current||0} / ${g.target} ${esc(g.unit)}</span></div><div class="study-progress"><i style="width:${p}%"></i></div></div>`}).join('')||'<p class="muted">No goals yet.</p>'}
  function renderAnalytics(){const weekStart=new Date();weekStart.setDate(weekStart.getDate()-6);const days=[];for(let i=0;i<7;i++){const d=new Date(weekStart);d.setDate(d.getDate()+i);const key=fmt(d),m=sumSessions(key);days.push(`<div class="bar-col"><span>${m}</span><i style="height:${Math.min(120,Math.max(4,m/3))}px"></i><small>${key.slice(5)}</small></div>`)}el('analyticsBox').innerHTML=`<div class="study-analytics-top"><div><b>${formatM(sumSessions())}</b><span>Total focus</span></div><div><b>${questions()}</b><span>Questions</span></div><div><b>${accuracy()}%</b><span>Accuracy</span></div><div><b>${data.tests.length}</b><span>Tests</span></div></div><div class="study-chart">${days.join('')}</div>`}
  function formatM(m){return `${Math.floor(m/60)}h ${m%60}m`}
  function modalForm(title,body,submit){el('studyFormTitle').textContent=title;el('studyFormBody').innerHTML=body;el('studyFormOverlay').hidden=false;el('studyFormSubmit').onclick=()=>{submit();el('studyFormOverlay').hidden=true;save()}}
  function options(arr){return arr.map(x=>`<option>${esc(x)}</option>`).join('')}
  function addTask(){modalForm('Add Study Task',`<input id="fTask" placeholder="e.g. Electrostatics PYQs" required><select id="fSubject">${options(subjects)}</select><select id="fType">${options(types)}</select><select id="fPriority"><option>Critical</option><option>High</option><option selected>Medium</option><option>Low</option></select><input id="fMinutes" type="number" min="5" value="45" placeholder="Minutes">`,`${''}`);el('studyFormSubmit').onclick=()=>{data.tasks.push({id:uid(),date:today(),task:el('fTask').value.trim(),subject:el('fSubject').value,type:el('fType').value,priority:el('fPriority').value,minutes:+el('fMinutes').value||30,done:false});el('studyFormOverlay').hidden=true;save()}}
  function addRevision(){modalForm('Schedule Revision',`<input id="fChapter" placeholder="Chapter" required><select id="fSubject">${options(subjects)}</select><select id="fLevel"><option>R1</option><option>R2</option><option>R3</option><option>R4</option></select><input id="fDue" type="date" value="${today()}">`,()=>data.revisions.push({id:uid(),chapter:el('fChapter').value.trim(),subject:el('fSubject').value,level:el('fLevel').value,due:el('fDue').value}));}
  function addBacklog(){modalForm('Add Backlog',`<input id="fChapter" placeholder="Chapter / topic" required><select id="fSubject">${options(subjects)}</select><select id="fPriority"><option>Critical</option><option>High</option><option selected>Medium</option><option>Low</option></select><input id="fHours" type="number" min="0.5" step="0.5" value="2" placeholder="Hours">`,()=>data.backlog.push({id:uid(),chapter:el('fChapter').value.trim(),subject:el('fSubject').value,priority:el('fPriority').value,hours:+el('fHours').value||1,status:'open'}));}
  function addMistake(){modalForm('Add Mistake',`<input id="fTopic" placeholder="Question / topic" required><select id="fSubject">${options(subjects)}</select><select id="fType"><option>Conceptual</option><option>Calculation</option><option>Formula</option><option>Silly mistake</option><option>Misread question</option><option>Time management</option></select><textarea id="fNote" placeholder="What went wrong / correct concept"></textarea>`,()=>data.mistakes.push({id:uid(),topic:el('fTopic').value.trim(),subject:el('fSubject').value,type:el('fType').value,note:el('fNote').value.trim()}));}
  function addTest(){modalForm('Add Mock Test',`<input id="fName" placeholder="Test name" required><input id="fDate" type="date" value="${today()}"><input id="fScore" type="number" placeholder="Score"><input id="fMax" type="number" placeholder="Maximum marks"><input id="fAttempted" type="number" placeholder="Attempted questions"><input id="fCorrect" type="number" placeholder="Correct questions">`,()=>data.tests.push({id:uid(),name:el('fName').value.trim(),date:el('fDate').value,score:+el('fScore').value||0,max:+el('fMax').value||0,attempted:+el('fAttempted').value||0,correct:+el('fCorrect').value||0}));}
  function addGoal(){modalForm('Add Goal',`<input id="fName" placeholder="Goal name" required><input id="fTarget" type="number" min="1" placeholder="Target"><input id="fUnit" placeholder="Unit e.g. hours, questions"><input id="fCurrent" type="number" min="0" value="0" placeholder="Current">`,()=>data.goals.push({id:uid(),name:el('fName').value.trim(),target:+el('fTarget').value||1,unit:el('fUnit').value.trim()||'units',current:+el('fCurrent').value||0}));}
  function addChapter(){modalForm('Add Chapter Performance',`<input id="fChapter" placeholder="Chapter" required><select id="fSubject">${options(subjects)}</select><input id="fAccuracy" type="number" min="0" max="100" placeholder="Accuracy %">`,()=>data.chapters.push({id:uid(),chapter:el('fChapter').value.trim(),subject:el('fSubject').value,accuracy:+el('fAccuracy').value||0}));}
  function startRecommendation(){const r=recommendation();const subject=(r.title.split(' — ')[0]||'Physics');const activity='Study Session';if(typeof openFeature==='function'){openFeature('focus');setTimeout(()=>{el('focusSubject')&&(el('focusSubject').value=subject);el('focusActivity')&&(el('focusActivity').value=activity);el('focusStartBtn')?.click()},100)}}
  document.addEventListener('click',e=>{
    if(e.target.closest('#studyHubOpen')) open();
    if(e.target.closest('#studyHubClose')) close();
    const tab=e.target.closest('.study-tab');if(tab)setTab(tab.dataset.tab);
    if(e.target.closest('#studyFormClose')||e.target.closest('#studyFormCancel'))el('studyFormOverlay').hidden=true;
    if(e.target.id==='studyHubOverlay')close();
    if(e.target.id==='studyFormOverlay')el('studyFormOverlay').hidden=true;
    if(e.target.closest('#addTask'))addTask(); if(e.target.closest('#addRevision'))addRevision();if(e.target.closest('#addBacklog'))addBacklog();if(e.target.closest('#addMistake'))addMistake();if(e.target.closest('#addTest'))addTest();if(e.target.closest('#addGoal'))addGoal();if(e.target.closest('#addChapter'))addChapter();
    const tg=e.target.closest('[data-task-toggle]');if(tg){const t=data.tasks.find(x=>x.id===tg.dataset.taskToggle);if(t)t.done=!t.done;save()}
    const td=e.target.closest('[data-task-delete]');if(td){data.tasks=data.tasks.filter(x=>x.id!==td.dataset.taskDelete);save()}
    const tr=e.target.closest('[data-revision]');if(tr){const r=data.revisions.find(x=>x.id===tr.dataset.revision);if(r){r.level=r.level==='R4'?'R4':`R${Number(r.level.slice(1))+1}`;r.due=r.level==='R4'?today():new Date(Date.now()+[0,3,7,14,30][Number(r.level.slice(1))]*86400000).toISOString().slice(0,10);save()}}
    const bd=e.target.closest('[data-backlog]');if(bd){const b=data.backlog.find(x=>x.id===bd.dataset.backlog);if(b)b.status=b.status==='done'?'open':'done';save()}
    const bdel=e.target.closest('[data-backlog-delete]');if(bdel){data.backlog=data.backlog.filter(x=>x.id!==bdel.dataset.backlogDelete);save()}
    const md=e.target.closest('[data-mistake-delete]');if(md){data.mistakes=data.mistakes.filter(x=>x.id!==md.dataset.mistakeDelete);save()}
    const xt=e.target.closest('[data-test-delete]');if(xt){data.tests=data.tests.filter(x=>x.id!==xt.dataset.testDelete);save()}
    if(e.target.closest('[data-action="startRec"]'))startRecommendation();
  });
  document.addEventListener('change',e=>{const cb=e.target.closest('[data-task]');if(cb){const t=data.tasks.find(x=>x.id===cb.dataset.task);if(t)t.done=cb.checked;save()}});
  window.addStudySession=(minutes,subject='General',questions=0,correct=0)=>{data.sessions.push({id:uid(),date:today(),minutes:+minutes||0,subject,questions:+questions||0,correct:+correct||0});save()};
  window.openStudyHub=open;
  document.addEventListener('DOMContentLoaded',()=>{render();});
})();
